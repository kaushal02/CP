# Instructions

Enter the following command:
```shell
make
```
