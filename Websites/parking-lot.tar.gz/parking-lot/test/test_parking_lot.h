#include "../src/parking_lot.h"

class TestParkingLot {
    ParkingLot* parking_lot;
public:
    TestParkingLot();
    ~TestParkingLot();
    void run();
private:
    std::unordered_map <VehicleType, int> floor1;
    std::unordered_map <VehicleType, int> floor3;
    std::unordered_map <VehicleType, int> floor4;
};