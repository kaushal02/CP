#include <cassert>
#include <unordered_map>
#include "test_parking_lot.h"
#include "../src/vehicle_type.h"

bool MatchMaps(std::unordered_map <VehicleType, int> l, std::unordered_map <VehicleType, int> r) {
    bool flag = true;
    flag &= l.size() == r.size();
    for (auto kv : l) {
        flag &= r[kv.first] == kv.second;
//        std::cout << kv.first << "->" << kv.second << ", ";
    }
//    std::cout << std::endl;
    for (auto kv : r) {
        flag &= l[kv.first] == kv.second;
//        std::cout << kv.first << "->" << kv.second << ", ";
    }
//    std::cout << std::endl;
    return flag;
}

TestParkingLot::TestParkingLot() {
    floor1[VehicleType::TWO_WHEELER] = 2;
    floor1[VehicleType::FOUR_WHEELER] = 5;
    floor3[VehicleType::TWO_WHEELER] = 10;
    floor3[VehicleType::FOUR_WHEELER] = 50;
    floor4[VehicleType::FOUR_WHEELER] = 10;

    std::unordered_map <int, std::unordered_map <VehicleType, int>> input;
    input[1] = floor1;
    input[3] = floor3;
    input[4] = floor4;
    parking_lot = new ParkingLot(input);
}

TestParkingLot::~TestParkingLot() {
    delete parking_lot;
}

void TestParkingLot::run() {
    // floors are created
    assert(MatchMaps(parking_lot->check_availability(1), floor1));
    assert(parking_lot->check_availability(2).empty());
    assert(MatchMaps(parking_lot->check_availability(3), floor3));
    assert(MatchMaps(parking_lot->check_availability(4), floor4));

    int booking2_1 = parking_lot->enter(1, VehicleType::TWO_WHEELER, "KA5US1347", "8318336956");
    int booking2_2 = parking_lot->enter(1, VehicleType::TWO_WHEELER, "KA5VH2143", "9936631988");

    // space is full
    assert(parking_lot->enter(1, VehicleType::TWO_WHEELER, "KA4US8761", "7009369569") == -1);
    assert(parking_lot->enter(4, VehicleType::TWO_WHEELER, "KA4US8761", "7009369569") == -1);

    // able to book after space is freed
    parking_lot->exit(booking2_1);
    int booking2_3 = parking_lot->enter(1, VehicleType::TWO_WHEELER, "JA2RF8293", "8757002311");
    assert(booking2_3 != -1);

    // remaining space
    int booking4_1 = parking_lot->enter(4, VehicleType::FOUR_WHEELER, "KA4US8761", "9936631988");
    int booking4_2 = parking_lot->enter(4, VehicleType::FOUR_WHEELER, "JA2RF8293", "9936631988");
    std::unordered_map <VehicleType, int> space4 = parking_lot->check_availability(4);
    assert(space4[VehicleType::TWO_WHEELER] == 0);
    std::cout << space4[VehicleType::FOUR_WHEELER] << std::endl;
    assert(space4[VehicleType::FOUR_WHEELER] == 8);
}
