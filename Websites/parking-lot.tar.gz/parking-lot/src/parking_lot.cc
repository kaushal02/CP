#include <unordered_map>
#include "parking_lot.h"

void ParkingLot::errorMessage(std::string err) {
    std::cout << err << std::endl;
}
Floor* ParkingLot::getFloor(int floor_num) {
    if (floors.find(floor_num) == floors.end()) {
        errorMessage("Please enter correct floor number.");
        return NULL;
    }
    return floors[floor_num];
}
Booking* ParkingLot::getBooking(int booking_num) {
    if (bookings.find(booking_num) == bookings.end()) {
        errorMessage("Please enter correct booking number.");
        return NULL;
    }
    return bookings[booking_num];
}

ParkingLot::ParkingLot(std::unordered_map <int, std::unordered_map <VehicleType, int>> spaces) {
    next_booking_id = 1;
    for (auto kv : spaces) {
        floors[kv.first] = new Floor(kv.second);
    }
}

ParkingLot::~ParkingLot() {
    for (auto kv : floors) {
        delete kv.second;
    }
}

// map of vehicle type to free parking space count on a given floor
std::unordered_map <VehicleType, int> ParkingLot::check_availability(int floor_num) {
    Floor* floor = getFloor(floor_num);
    if (floor) {
        return floor->check_availability();
    }
    return std::unordered_map <VehicleType, int>();
}

// booking id for this entry
int ParkingLot::enter(int floor_num, VehicleType type, std::string vehicle_num, std::string contact_num) {
    Floor* floor = getFloor(floor_num);
    Booking* booking = floor->park(type, vehicle_num, contact_num, next_booking_id);
    if (booking) {
        bookings[next_booking_id] = booking;
        std::cout << "Booked successfully with id = " << next_booking_id << std::endl;
        return next_booking_id++;
    }
    errorMessage("Can not be parked due to some error.");
    return -1;
}

// cost of this booking
int ParkingLot::exit(int booking_id) {
    Booking* booking = getBooking(booking_id);
    int amount = -1;
    if (booking) {
        amount = booking->pay();
        delete booking;
    }
    return amount;
}
