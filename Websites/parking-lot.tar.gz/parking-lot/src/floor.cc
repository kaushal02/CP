#include <unordered_map>
#include "floor.h"
#include "vehicle_type.h"

Floor::Floor(std::unordered_map <VehicleType, int> spaces) {
    for (auto kv : spaces) {
       parking_spaces[kv.first] = std::vector<ParkingSpace*>(kv.second, new ParkingSpace(kv.first));
    }
}

Floor::~Floor() {
   for (auto kv : parking_spaces) {
       for (ParkingSpace* parking_space : kv.second) {
           delete parking_space;
       }
   }
}

std::unordered_map <VehicleType, int> Floor::check_availability() {
   std::unordered_map <VehicleType, int> res;
   for (auto kv : parking_spaces) {
       for (ParkingSpace* parking_space : kv.second) {
           if (parking_space->isFree()) {
               res[kv.first]++;
           }
       }
   }
   return res;
}

Booking* Floor::park(VehicleType type, std::string vehicle_num, std::string contact_num, int booking_id) {
    for (ParkingSpace* parking_space : parking_spaces[type]) {
        if (parking_space->isFree()) {
            parking_space->book();
            return new Booking(booking_id, vehicle_num, contact_num, parking_space);
        }
    }
    return NULL;
}
