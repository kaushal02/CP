#include "parking_space.h"

ParkingSpace::ParkingSpace(VehicleType vehicle_type) {
    type = vehicle_type;
    is_free = true;
}

bool ParkingSpace::isFree() {
    return is_free;
}

void ParkingSpace::book() {
    is_free = false;
}

void ParkingSpace::free() {
    is_free = true;
}