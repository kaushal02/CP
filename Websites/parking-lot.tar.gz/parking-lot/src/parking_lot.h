#pragma once
#include <unordered_map>
#include "floor.h"
#include "booking.h"
#include "vehicle_type.h"

class ParkingLot {
    int next_booking_id;
    std::unordered_map <int, Floor*> floors;
    std::unordered_map <int, Booking*> bookings;

    void errorMessage(std::string);
    Floor* getFloor(int);
    Booking* getBooking(int);
public:
    ParkingLot(std::unordered_map <int, std::unordered_map <VehicleType, int>>);
    ~ParkingLot();
    std::unordered_map <VehicleType, int> check_availability(int);
    int enter(int, VehicleType, std::string, std::string);
    int exit(int);
};
