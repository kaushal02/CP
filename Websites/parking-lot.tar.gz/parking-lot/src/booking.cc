#include "booking.h"

Booking::Booking(int booking_id, std::string vehicle_num, std::string contact_num, ParkingSpace* space) {
    id = (booking_id);
    vehicle_number = (vehicle_num);
    contact_number = (contact_num);
    parking_space = (space);
}

Booking::~Booking() {
    parking_space->free();
}

int Booking::pay() {
    return 1;
}