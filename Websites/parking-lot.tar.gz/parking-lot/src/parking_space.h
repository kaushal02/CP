#pragma once
#include "vehicle_type.h"

class ParkingSpace {
    VehicleType type;
    bool is_free;
public:
    ParkingSpace(VehicleType);
    ~ParkingSpace() {}
    bool isFree();
    void book();
    void free();
};