#pragma once
#include <iostream>
#include "parking_space.h"

class Booking {
    int id;
    std::string vehicle_number;
    std::string contact_number;
    ParkingSpace* parking_space;
public:
    Booking(int, std::string, std::string, ParkingSpace*);
    ~Booking();
    int pay();
};
