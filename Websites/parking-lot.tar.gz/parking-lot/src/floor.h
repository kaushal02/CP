#pragma once
#include <unordered_map>
#include <vector>
#include "booking.h"
#include "vehicle_type.h"

class Floor {
    std::unordered_map <VehicleType, std::vector <ParkingSpace*>> parking_spaces;
    std::unordered_map <int, ParkingSpace*> bookings;
public:
    Floor(std::unordered_map <VehicleType, int>);
    ~Floor();
    std::unordered_map <VehicleType, int> check_availability();
    Booking* park(VehicleType, std::string, std::string, int);
};
