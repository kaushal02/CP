#include "test/test_parking_lot.h"
using namespace std;

int main() {
    TestParkingLot my_parking_lot;
    my_parking_lot.run();
    return 0;
}